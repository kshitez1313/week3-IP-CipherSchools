var date=new Date();
console.log(date);
console.log(date.getTime());
console.log(date.getFullYear());

const months=["January",
    "February", 
    "March", 
    "April", 
    "May", 
    "June", 
    "July", 
    "August", 
    "September", 
    "October", 
    "November", 
    "December" ];
    console.log(months[date.getMonth()]);